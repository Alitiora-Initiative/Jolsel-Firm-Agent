// src/compliance/mrGrumpy.ts
import { CorporateContext } from '../index';

export class MrGrumpy {
    static audit(ctx: CorporateContext) {
        if (ctx.recentLossStreak > 0) {
            console.log(`[Mr. Grumpy] Angrily looking over previous failures! Threat level increased.`);
            ctx.suggestedPositionSizeSol = 0.01; // Slashes allocation instantly down to safe minimum
        } else {
            console.log("[Mr. Grumpy] No recent losses. Still highly skeptical, watching your execution like a hawk.");
            ctx.suggestedPositionSizeSol = 0.1; 
        }
    }
}
