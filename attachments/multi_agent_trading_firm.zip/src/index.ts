// src/index.ts
import { Bscoter } from './discovery/bscoter';
import { Analuszer } from './discovery/analuszer';
import { Forecaster } from './planning/forecaster';
import { MrGrumpy } from './compliance/mrGrumpy';
import { RiskManager } from './compliance/riskManager';
import { Judge } from './executive/judge';
import { Verdicter } from './executive/verdicter';
import { Trader } from './executive/trader';
import { RecordKeeper } from './audit/recordKeeper';
import { Teacher } from './audit/teacher';

export interface CorporateContext {
    tick: number;
    walletBalanceSol: number;
    assetClass: 'MEME' | 'STOCK' | 'PERP';
    targetToken?: string;
    volume24h?: number;
    socialScore?: number;
    analyticalCertainty: number;
    isTradeWorthIt: boolean;
    stopLossPercentage: number;
    suggestedPositionSizeSol: number;
    approvedByCompliance: boolean;
    verdictIssued: boolean;
    executionTxId?: string;
    firmBlockStatus: boolean;
    recentLossStreak: number;
}

class TradingFirm {
    private context: CorporateContext = {
        tick: 0,
        walletBalanceSol: 20.0, // Starting micro-capital
        assetClass: 'MEME',
        analyticalCertainty: 0,
        isTradeWorthIt: false,
        stopLossPercentage: 0,
        suggestedPositionSizeSol: 0,
        approvedByCompliance: true,
        verdictIssued: false,
        firmBlockStatus: false,
        recentLossStreak: 0
    };

    async runTick() {
        this.context.tick++;
        console.log(`\n--- FIRM TICK ${this.context.tick} STARTED ---`);
        
        if (this.context.firmBlockStatus) {
            console.log("Firm operations are currently FROZEN by Compliance.");
            return;
        }

        // 1. DISCOVERY LAYER
        Bscoter.scout(this.context);
        Analuszer.analyze(this.context);

        if (this.context.analyticalCertainty >= 80) {
            // 2. PLANNING LAYER
            Forecaster.simulate(this.context);

            if (this.context.isTradeWorthIt) {
                // 3. COMPLIANCE LAYER
                MrGrumpy.audit(this.context);
                RiskManager.enforce(this.context);

                if (this.context.approvedByCompliance) {
                    // 4. EXECUTIVE LAYER
                    Judge.evaluate(this.context);
                    Verdicter.sign(this.context);

                    if (this.context.verdictIssued) {
                        await Trader.execute(this.context);
                        // 5. AUDIT LAYER
                        RecordKeeper.log(this.context);
                    }
                }
            }
        }

        // End of Day cycle simulation
        if (this.context.tick % 10 === 0) {
            Teacher.runDailyQuiz(this.context);
        }
    }
}

const firm = new TradingFirm();
setInterval(() => firm.runTick(), 5000);
